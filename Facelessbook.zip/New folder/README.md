# Facelessbook
A helper Chrome extension that hides identifiable info from Facebook. Helpful for screenshotters. Made at hackharvard2017
